<?php

namespace WapplerSystems\ZabbixClient\Exception;


class InvalidArgumentException extends \InvalidArgumentException
{


}
