<?php

namespace WapplerSystems\ZabbixClient\Exception;


class InvalidOperationException extends \InvalidArgumentException
{


}
