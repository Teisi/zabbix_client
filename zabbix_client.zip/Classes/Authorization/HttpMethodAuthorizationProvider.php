<?php

namespace WapplerSystems\ZabbixClient\Authorization;

/**
 * This file is part of the "zabbix_client" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 */

use WapplerSystems\ZabbixClient\Utility\Configuration;


class HttpMethodAuthorizationProvider
{
    /**
     * ServerRequest
     *
     * @var \TYPO3\CMS\Core\Http\ServerRequest
     */
    protected $request;

    /**
     * Extension configuration
     *
     * @var array
     */
    protected $config = [];

    public function __construct(\TYPO3\CMS\Core\Http\ServerRequest $request) {
        $this->request = $request;
        $this->config = Configuration::getExtConfiguration();
    }

    /**
     * @return bool
     */
    public function isAuthorized(): bool
    {
        $allowedHttpMethods = explode('-', $this->config['httpMethod']);
        if(in_array($this->request->getMethod(), $allowedHttpMethods)) {
            return true;
        }

        return false;
    }
}
